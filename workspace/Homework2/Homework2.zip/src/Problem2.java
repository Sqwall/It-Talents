public class Problem2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (byte num = -20; num < 51; num++) {
        System.out.println(num);
		}

	}

}
