
public class Problem1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		for (byte num = 0; num < 101; num++ ) {
		System.out.println(num);
		}
	}

}
