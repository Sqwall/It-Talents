
public class Problem3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (byte num = -10; num < 11; num++) {
			if ((num % 2) == 0);			
	        System.out.println(num);
			}
		
	}

}
