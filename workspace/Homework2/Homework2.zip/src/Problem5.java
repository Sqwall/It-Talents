import java.util.Scanner;

public class Problem5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Please input a number.");
		long num = sc.nextLong();
		System.out.println("Please input a different number.");
		long num2 = sc.nextLong();
		
		if (num == num2) {
			System.out.println("Numbers are equal. Please restart and input 2 valid numbers.");
			return;
			
		}
		long num3;

		if (num < num2) {
			for (num3 = num; num3 < num2 + 1; num3++) {
				System.out.println(num3);
			}
		}

		else {
			for (num3 = num2; num3 < num + 1; num3++) {
				System.out.println(num3);
			}
		}

	}
}
