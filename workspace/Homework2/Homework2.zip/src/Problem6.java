import java.util.Scanner;

public class Problem6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Please input a number.");
		long num = sc.nextLong();
		
		long num2 = 0;
		long num3 = 0;
		
		for ( num2 = 1; num2 <= num ; num2++)  {
			num3 = (num3 + num2);
			}
		
		System.out.println(num3);
		
	}

}
