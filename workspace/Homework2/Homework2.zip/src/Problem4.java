
public class Problem4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (byte num = 10; num > 0; num-- ) {
		System.out.println(num);
		}
	}

}
